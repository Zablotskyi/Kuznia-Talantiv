package org.talentsforge;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.List;

public class IPv4Check {

    private static final Logger LOGGER_INFO = LoggerFactory.getLogger("info");
    private static final String FILE = "blacklist.txt";

    public void run() throws IOException {

        long startProgramTime = 0L;

        List<String> ipv4List = FileWorker.read(FILE);

        System.out.println("Hello my dear friend! \n" +
                "Enter your IP and press \"enter\" \n" +
                "or enter \"quit\" to exit");

        BufferedReader readerIp = new BufferedReader(new InputStreamReader(System.in));
        String ip = readerIp.readLine();

        while (!ip.equals("quit")) {

            if (FileWorker.getLastModifyTime(FILE) > startProgramTime) {
                ipv4List = FileWorker.read(FILE);

                startProgramTime = new Date().getTime();
            }
            if (!new ValidIP().validIP(ip)) {
                System.out.println("Invalid IP address");
                LOGGER_INFO.info(ip + " Invalid IP address");
            } else {
                if (ipv4List.contains(ip)) {
                    System.out.println("Access disallowed");
                    LOGGER_INFO.info(ip + " Access disallowed");
                } else {
                    System.out.println("Access allowed");
                    LOGGER_INFO.info(ip + " Access allowed");
                }
            }
            System.out.println("enter new IP or enter \"quit\" to exit");

            ip = readerIp.readLine();
        }
    }
}