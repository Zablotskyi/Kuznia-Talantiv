package org.talentsforge;

import java.io.IOException;

public class IpCheckMain {

    public static void main(String[] args) throws IOException {
        new IPv4Check().run();
    }
}
