package org.talentsforge;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.JOptionPane;
import java.awt.Component;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileWorker {

    private static final Logger LOGGER_WARN = LoggerFactory.getLogger("warn");
    private static Component frame;

    public static List<String> read(String fileName) {

        List<String> ipv4List = new ArrayList<>();

        exists(fileName);

        try {
            BufferedReader in = new BufferedReader(new FileReader(fileName));
            try {
                String s;
                while ((s = in.readLine()) != null) {
                    ipv4List.add(s);
                }
            } finally {
                in.close();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return ipv4List;
    }

    private static void exists(String fileName) {
        File file = new File(fileName);
        if (!file.exists()) {
            LOGGER_WARN.warn("File with name " + file.getName() + " not found");
            JOptionPane.showMessageDialog(frame, "File with name " + file.getName() + " not found");
        }
    }

    public static long getLastModifyTime(String fileName) {
        File file = new File(fileName);

        return file.lastModified();
    }
}