package org.talentsforge;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class IPv4Check {

    List<String> ipv4List = new ArrayList<>();

    public void run() throws IOException {
        System.out.println("Hello my dear friend! \n" +
                "Enter your IP and press \"enter\" \n" +
                "or enter \"quit\" to exit");
        BufferedReader readerIp = new BufferedReader(new InputStreamReader(System.in));
        String ip = readerIp.readLine();

        while (!"quit".equals(ip)) {
            try (BufferedReader bufferAddListIp = new BufferedReader(new InputStreamReader(new FileInputStream("blacklist.txt")))) {
                while (bufferAddListIp.ready()) {
                    String ipv4 = bufferAddListIp.readLine();
                    ipv4List.add(ipv4);
                }

                if (!new ValidIP().validIP(ip)) {
                    System.out.println("Invalid IP address");
                } else {
                    if (ipv4List.contains(ip)) {
                        System.out.println("Access disallowed");
                    } else {
                        System.out.println("Access allowed");
                    }
                }

                System.out.println("enter new IP or enter \"quit\" to exit");
                ipv4List.clear();
                ip = readerIp.readLine();
            }
        }
    }
}
